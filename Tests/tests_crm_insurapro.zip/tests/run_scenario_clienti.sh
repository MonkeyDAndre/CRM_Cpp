#!/bin/bash
set -e
cd "$(dirname "$0")/.."

echo "--- Scenario: aggiungi cliente OK ---"
OUTPUT=$(./crm < tests/scenari/clienti_aggiungi_ok.txt)
echo "$OUTPUT" | grep -q "Cliente aggiunto" || (echo "FALLITO: manca conferma aggiunta" && exit 1)

echo "--- Scenario: correzione email non valida ---"
OUTPUT=$(./crm < tests/scenari/clienti_aggiungi_correzione.txt)
echo "$OUTPUT" | grep -qi "email non valida" || (echo "FALLITO: manca messaggio di errore email" && exit 1)
echo "$OUTPUT" | grep -q "Cliente aggiunto" || (echo "FALLITO: il cliente non e' stato comunque aggiunto dopo la correzione" && exit 1)

echo "--- Scenario: modifica cliente non trovato ---"
OUTPUT=$(./crm < tests/scenari/clienti_modifica_non_trovato.txt)
echo "$OUTPUT" | grep -qi "Cliente non trovato" || (echo "FALLITO: manca messaggio cliente non trovato" && exit 1)

echo "--- Scenario: input menu non numerico ---"
OUTPUT=$(./crm < tests/scenari/clienti_input_non_numerico.txt)
echo "$OUTPUT" | grep -qi "scelta non valida\|input non valido" || (echo "FALLITO: manca messaggio di input non valido" && exit 1)

echo "TUTTI GLI SCENARI PASSATI"
