#!/bin/bash
set -e
cd "$(dirname "$0")/.."

WORKDIR=$(mktemp -d)
cp tests/fixtures/flusso/*.csv "$WORKDIR/"
cp crm "$WORKDIR/"

cd "$WORKDIR"
cat > input.txt << 'INPUT'
1
1
Anna
Verdi
3339876543
anna.verdi@email.com
VRDNNA90C41H501U
05/03/1990
0
3
INPUT

./crm < input.txt > output.txt

echo "--- Verifica: clienti.csv contiene sia Mario che Anna dopo l'uscita ---"
grep -q "Mario" clienti.csv || (echo "FALLITO: Mario scomparso da clienti.csv" && exit 1)
grep -q "Anna" clienti.csv || (echo "FALLITO: Anna non salvata in clienti.csv" && exit 1)

echo "--- Verifica: scrittura fallita non termina il programma ---"
cat > input2.txt << 'INPUT'
1
2
0
3
INPUT
chmod 000 clienti.csv contratti.csv appuntamenti.csv
OUTPUT2=$(./crm < input2.txt 2>&1 || true)
chmod 644 clienti.csv contratti.csv appuntamenti.csv
echo "$OUTPUT2" | grep -qi "errore" || (echo "FALLITO: manca messaggio di errore su scrittura fallita" && exit 1)
echo "$OUTPUT2" | grep -q "Anna" || (echo "FALLITO: il programma non ha continuato a rispondere dopo l'errore di scrittura (visualizza clienti non ha mostrato Anna)" && exit 1)

cd -
rm -rf "$WORKDIR"
echo "TUTTI GLI SCENARI PASSATI"
