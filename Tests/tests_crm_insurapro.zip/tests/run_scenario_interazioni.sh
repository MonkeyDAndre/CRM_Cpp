#!/bin/bash
set -e
cd "$(dirname "$0")/.."

echo "--- Scenario: aggiungi appuntamento a cliente esistente ---"
OUTPUT=$(./crm < tests/scenari/interazioni_aggiungi_appuntamento.txt)
echo "$OUTPUT" | grep -qi "Appuntamento" || (echo "FALLITO: appuntamento non mostrato" && exit 1)
echo "$OUTPUT" | grep -q "15/03/2026" || (echo "FALLITO: data appuntamento non trovata in output" && exit 1)

echo "--- Scenario: premio negativo richiede reinserimento solo di quel campo ---"
OUTPUT=$(./crm < tests/scenari/interazioni_premio_negativo.txt)
echo "$OUTPUT" | grep -qi "premio" || (echo "FALLITO: manca messaggio sul premio" && exit 1)
echo "$OUTPUT" | grep -qi "Contratto" || (echo "FALLITO: contratto non aggiunto dopo la correzione" && exit 1)

echo "--- Scenario: interazioni di cliente inesistente ---"
OUTPUT=$(./crm < tests/scenari/interazioni_cliente_inesistente.txt)
echo "$OUTPUT" | grep -qi "Cliente non trovato" || (echo "FALLITO: manca messaggio cliente non trovato" && exit 1)

echo "--- Scenario: interazioni sopravvivono a eliminazione cliente ---"
OUTPUT=$(./crm < tests/scenari/interazioni_sopravvivono_a_eliminazione_cliente.txt)
echo "$OUTPUT" | grep -qi "Cliente eliminato" || (echo "FALLITO: cliente non eliminato" && exit 1)
echo "$OUTPUT" | grep -qi "Appuntamento" || (echo "FALLITO: l'appuntamento e' sparito dopo l'eliminazione del cliente" && exit 1)

echo "TUTTI GLI SCENARI PASSATI"
