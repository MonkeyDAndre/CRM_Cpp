#!/bin/bash
set -e
cd "$(dirname "$0")/.."

WORKDIR=$(mktemp -d)
cp -r InsuraProCRM "$WORKDIR/"
cd "$WORKDIR/InsuraProCRM"
rm -f clienti.csv appuntamenti.csv contratti.csv crm

echo "--- Verifica: compilazione pulita senza warning ---"
g++ -Wall -Wextra *.cpp -o crm 2> build_warnings.txt
if [ -s build_warnings.txt ]; then
    echo "FALLITO: warning di compilazione presenti:"
    cat build_warnings.txt
    exit 1
fi

echo "--- Verifica: avvio a freddo senza CSV pre-esistenti ---"
echo "3" | ./crm > avvio.txt 2>&1
grep -qi "MENU PRINCIPALE" avvio.txt || (echo "FALLITO: il menu non parte senza CSV" && exit 1)
test -f clienti.csv || (echo "FALLITO: clienti.csv non creato dopo il primo salvataggio" && exit 1)

echo "--- Verifica: README contiene il comando di build esatto ---"
grep -q "g++ \*.cpp -o crm" README.md || (echo "FALLITO: README non contiene il comando esatto" && exit 1)

cd -
rm -rf "$WORKDIR"
echo "TUTTI GLI SCENARI PASSATI"
